package com.zulu.consumer.flightapiclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightApiClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightApiClientApplication.class, args);
	}

}
