package com.zulu.provider.flightapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
